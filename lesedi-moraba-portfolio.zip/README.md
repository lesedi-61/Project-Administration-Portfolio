# Lesedi Moraba | Portfolio

A static website (plain HTML, CSS and JavaScript). No build step is needed.

## Files
- `index.html` : the whole website
- `assets/Lesedi_Moraba_CV.pdf` : the CV (the Download CV buttons use this file)
- `assets/cv/` : CV page pictures shown by View CV
- `assets/docs/` : project document pictures shown by each View button

## Deploy on GitHub Pages
1. Sign in to GitHub and click **New repository**.
2. Name it (for example `lesedi-moraba`), set it to **Public**, and click **Create repository**.
3. Click **uploading an existing file**. Unzip this folder first, then drag in everything inside it
   (`index.html`, the `assets` folder, `README.md`, `.nojekyll`) and click **Commit changes**.
4. Go to **Settings > Pages**. Under **Build and deployment**, set Source to **Deploy from a branch**,
   choose branch **main** and folder **/ (root)**, then click **Save**.
5. Wait 1 to 3 minutes. Your site will be at `https://lesedi-61.github.io/lesedi-moraba/`.

## Updating
- Replace a picture in `assets/docs/` with a new one of the same file name.
- Replace `assets/Lesedi_Moraba_CV.pdf` (and `assets/cv/` pictures) when your CV changes.
- Text is edited directly in `index.html`.
